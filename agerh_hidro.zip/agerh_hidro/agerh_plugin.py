# -*- coding: utf-8 -*-
"""
Classe principal de integração do Plugin com o QGIS.
"""

import os
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMenu

from .agerh_dialog import AgerhDialog


class AgerhPlugin:
    """
    Plugin QGIS para carregar dados hidrológicos e outorgas da AGERH-ES.
    """

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.menu_agerh = None
        self.dialog = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        self.action = QAction(icon, "AGERH Hidro Dados", self.iface.mainWindow())
        self.action.setStatusTip("Importar dados de Qualidade da Água (IQA) e Outorgas da AGERH-ES")
        self.action.triggered.connect(self.run)

        # Adiciona na barra de ferramentas de plugins/web
        self.iface.addToolBarIcon(self.action)

        # Adiciona no menu 'Web' do QGIS
        self.iface.addPluginToWebMenu("AGERH - Recursos Hídricos", self.action)

        # Cria menu próprio 'AGERH' na barra de menus principal do QGIS para fácil localização
        menu_bar = self.iface.mainWindow().menuBar()
        self.menu_agerh = QMenu("AGERH", menu_bar)
        self.menu_agerh.addAction(self.action)
        menu_bar.addMenu(self.menu_agerh)

    def unload(self):
        if self.action:
            self.iface.removePluginWebMenu("AGERH - Recursos Hídricos", self.action)
            self.iface.removeToolBarIcon(self.action)

        if self.menu_agerh:
            menu_bar = self.iface.mainWindow().menuBar()
            menu_bar.removeAction(self.menu_agerh.menuAction())

        if self.dialog:
            self.dialog.close()

    def run(self):
        if not self.dialog:
            self.dialog = AgerhDialog(self.iface, parent=self.iface.mainWindow())
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
